package dit042.exceptions;

import dit042.UserInterface;

public class UUIDTypeException extends Exception {
    private static final long serialVersionUID = 1203L;

    public UUIDTypeException() {
        super();
    }
}